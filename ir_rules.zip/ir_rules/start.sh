#!/bin/bash

# Flush existing rules
iptables -F

# Allow incoming SSH traffic (change the port if needed)
iptables -A INPUT -p tcp --dport 22 -j ACCEPT

# Allow incoming connections from the whitelisted IP addresses
while read line; do iptables -A INPUT -s $line -j ACCEPT; done < ip.txt

# Drop all other incoming connections
iptables -A INPUT -j DROP
